function Berniotis(varargin)
% Run an experiment

% Version 1.0 -- March 2018


%% initialisation and fixed parameter values
VERSION=1.0;
rng('shuffle')
levitts_index = 1;

%% Settings for level
if ispc
    VolumeSettingsFile='VolumeSettings.txt';
    [~, OutRMS]=SetLevels(VolumeSettingsFile);
else ismac
    !osascript set_volume_applescript.scpt
    % VolumeSettingsFile='VolumeSettingsMac.txt';
end

%% get control parameters by picking up defaults and specified values from args
if ~rem(nargin,2)
    error('You should not have an even number of input arguments');
end
SpecifiedArgs=BerniotisParseArgs(varargin{1},varargin{2:end});
% now set all parameters obtained
fVars=fieldnames(SpecifiedArgs);
for f=1:length(fVars)
    if ischar(eval(['SpecifiedArgs.' char(fVars{f})]))
        eval([char(fVars{f}) '=' '''' eval(['SpecifiedArgs.' char(fVars{f})]) ''';']);
    else % it's a number
        eval([char(fVars{f}) '='  num2str(eval(['SpecifiedArgs.' char(fVars{f})])) ';'])
    end
end


%% further initialisations
LEVITTS_CONSTANT = [1 LevittsK];
SNR_dB = starting_SNR; % current level
NoiseBandLimits=[ToneFreq-NoiseBandWidth/2 ToneFreq+NoiseBandWidth/2];

% for fixed level testing
if START_change_dB==0 || MIN_change_dB == 0
    MIN_change_dB = 0;
    START_change_dB=0;
    INITIAL_TURNS = 99;
    FINAL_TURNS = 99;
    LEVITTS_CONSTANT = [1 1];
    MaxBumps=99;
end

%% read in all the necessary faces for feedback
if ~strcmp(FeedBack, 'None')
    FacesDir = fullfile('Faces',FacePixDir,'');
    SmileyFace = imread(fullfile(FacesDir,'smile24.bmp'),'bmp');
    WinkingFace = imread(fullfile(FacesDir,'wink24.bmp'),'bmp');
    FrownyFace = imread(fullfile(FacesDir,'frown24.bmp'),'bmp');
    %ClosedFace = imread(fullfile(FacesDir,'closed24.bmp'),'bmp');
    %OpenFace = imread(fullfile(FacesDir,'open24.bmp'),'bmp');
    %BlankFace = imread(fullfile(FacesDir,'blank24.bmp'),'bmp');
    CorrectImage=SmileyFace;
    IncorrectImage=FrownyFace;
end

%%	setup a few starting values for adaptive track
% the original code was in a situation where SNR was specified in CCRM
previous_change = -1; % assume track is initially moving from easy to hard
num_turns = 0;
num_final_trials = 0;
change = START_change_dB;
inc = (START_change_dB-MIN_change_dB)/INITIAL_TURNS;
limit = 0;
response_count = 0;
trial = 0;
nWavSection=0;

if ~exist(OutputDir, 'dir')
    status = mkdir(OutputDir);
    if status==0
        error('Cannot create new output directory for results: %s.\n', OutputDir);
        return;
    end
end

%% determine a code for the feedback type to put in the file name
if strcmp(FeedBack,'None')
    FeedBackCode = '0';
elseif strcmp(FeedBack,'Neutral')
    FeedBackCode = 'N';
elseif strcmp(FeedBack,'Corrective')
    FeedBackCode = 'C';
elseif strcmp(FeedBack,'AlwaysGood')
    FeedBackCode = 'G';
else
    error('Illegal type of Feedback specified');
end

%% get start time and date
StartTime=fix(clock);
StartTimeString=sprintf('%02d:%02d:%02d',...
    StartTime(4),StartTime(5),StartTime(6));
StartDate=date;

%% construct the output data file name
% get the root name of the target and noise files
% put masker, date and time on filenames so as to ensure a single file per test
FileNamingStartTime = sprintf('%02d-%02d-%02d',StartTime(4),StartTime(5),StartTime(6));
% Construct a condition code
if InterauralTonePhase==0
    phz='00';
else
    phz='pi';
end
if strcmp(fixed,'signal')
    fx='Sig';
else
    fx='Nz';
end

CondCode=sprintf('%dHzS-S%s-%03drms-Fix%s',ToneFreq,phz,round(rms2use*1000),fx);
FileListenerName=[ListenerName '_' CondCode '_' StartDate '_' FileNamingStartTime];
OutFile = fullfile(OutputDir, [FileListenerName '.csv']);
SummaryOutFile = fullfile(OutputDir, [FileListenerName '_sum.csv']);


%% write some headings and preliminary information to the output file
fout = fopen(OutFile, 'at');
fprintf(fout, 'listener,CondCode,date,time,trial,CatchTrial,SNR,correct,target,InQuiet,HRTF,T_az,M_az,masker,MskStart,M1talker,M1colour,M1digit,M1type,M2talker,M2colour,M2digit,M2type,Ttalker,Tcolour,Tdigit,Ttype,Rcolour,Rdigit,rTime,rev');
fclose(fout);

%% wait to start
GoOrMessageButton('String', StartMessage)

%%	do adaptive tracking until stop criterion */
while (num_turns<FINAL_TURNS  && limit<=MaxBumps && trial<MAX_TRIALS)
    num_correct = 0; num_wrong = 0;
    % present same level until change criterion reached */
    while ((num_correct < LEVITTS_CONSTANT(levitts_index)) && (num_wrong==0))
        trial=trial+1;
        % choose a random interval of 3
        Order=randi(3);
        
        % generate the appropriate sounds
        w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR_dB, SampFreq);
        
        
        % play it out and score it.
        if ~DEBUG
            
            correct = Order==;
        else % stat rat section for output format, etc.
            % get 2 right at start of session,
            % then ensure correct response 0.7 the time thereafter
            % otherwise guess 'pink' and 8
            Dresp='';
            if trial<=2 || (rand(1)<0.7)
                Cresp=char(TargetCodes.colour);
                if DigitResponse
                    Dresp=TargetCodes.digit;
                end
            else
                Cresp='pink';
                if DigitResponse
                    Dresp=8;
                end
            end
            if DigitResponse
                correct = strcmp(char(TargetCodes.colour),Cresp)&&(TargetCodes.digit==Dresp);
            else
                correct = strcmp(char(TargetCodes.colour),Cresp);
            end
        end
        TimeOfResponse = clock;
        
        % test for quitting
        if strcmp(Cresp,'quit')
            break
        end
        
        % give feedback if necessary
        if ~strcmp(FeedBack,'None') && ~DEBUG
            if strcmp(FeedBack,'Neutral')
                image(WinkingFace);
            elseif (correct && strcmp(FeedBack,'Corrective')) || strcmp(FeedBack,'AlwaysGood')
                image(SmileyFace);
            else
                image(FrownyFace);
            end
            set(gca,'Visible','off')
            pause(0.5)
            image(AnimalImage)
            set(gca,'Visible','off')
        end
        
        fout = fopen(OutFile, 'at');
        % print out relevant information
        %'listener,date,time,trial,SNR,correct,target,InQuiet,masker,
        %    M1colour,M1digit,M2colour,M2digit,Tcolour,Tdigit,
        %    Rcolour,Rdigit,rTime,rev'
        fprintf(fout, '\n%s,%s,%s,%s,%3d,%1d,%+5.1f,%d,%s,%d,%s,%g,%g,', ...
            ListenerName,CondCode,StartDate,StartTimeString,trial,isCatchTrial,SNR_dB,correct, ...
            char(targets(TargetOrder(trial))),PresentInQuiet,HRTF,TargetAz,MaskerAz);
        if strcmp(TestType,'MultiTalker')
            if strcmp(MultipleMaskerType,'VariableMasker')
                fprintf(fout, '%s:%s,,',...
                    MaskerCodes(1).fileName,MaskerCodes(2).fileName);
                fprintf(fout, '%s,%s,%d,%s,%s,%s,%d,%s,', ...
                    MaskerCodes(1).talker, MaskerCodes(1).colour, MaskerCodes(1).digit, MaskerCodes(1).talkerType, ....
                    MaskerCodes(2).talker, MaskerCodes(2).colour, MaskerCodes(2).digit, MaskerCodes(2).talkerType);
            else
                fprintf(fout, '%s,%d,%s,%d,,,', ...
                    char(MultipleMaskerFiles(1)),MaskerWavStart(1),...
                    char(MultipleMaskerFiles(2)),MaskerWavStart(2));
            end
        elseif strcmp(TestType,'VariableMasker')
            fprintf(fout, '%s,,', char(maskers(MaskersOrder(iMaskers))));
            fprintf(fout, '%s,%d,,,', MaskerCodes.colour, MaskerCodes.digit);
        else
            fprintf(fout, '%s,%d,,,,,,,,,', MaskerFile,MaskerWavStart);
        end
        fprintf(fout, '%s,%s,%d,%s,%s,%d,', ...
            TargetCodes.talker, TargetCodes.colour, TargetCodes.digit, TargetCodes.talkerType, Cresp, Dresp);
        fprintf(fout, '%02d:%02d:%05.2f',...
            TimeOfResponse(4),TimeOfResponse(5),TimeOfResponse(6));
        % close file for safety
        fclose(fout);
        
        % set level back if changed for catch trial
        SNR_dB=tmp_SNR;
        
        % ignore initial errors
        if ~isCatchTrial && ((trial>IgnoreTrials) || correct) % do the normal thing
            % score the response as correct or wrong */
            if correct
                num_correct=num_correct+1;
            else
                num_wrong=num_wrong+1;
            end
            
            % also keep track of levels visited: perhaps better
            if ((change-0.001) <= MIN_change_dB) % allow for rounding error
                % we're in the final stretch
                num_final_trials = num_final_trials + 1;
                final_trials(num_final_trials) = SNR_dB;
            end
        end
        
    end % end of Levitt 'while' loop
    
    % test for quitting
    if strcmp(Cresp,'quit')
        break
    end
    
    % decide in which direction to change levels
    if (num_correct == LEVITTS_CONSTANT(levitts_index))
        current_change = -1;
    else
        current_change = 1;
    end
    
    % are we at a turnaround? (defined here as any change in direction) If so, do a few things
    if (previous_change ~= current_change)
        % move to next value of Levitt's constant if not already done
        if (levitts_index==1)
            levitts_index=2;
        end
        % reduce step proportion if not minimum */
        if ((change-0.001) > MIN_change_dB) % allow for rounding error
            change = change-inc;
        else % final turnarounds, so start keeping a tally
            num_turns = num_turns + 1;
            reversals(num_turns)=SNR_dB;
            fout = fopen(OutFile, 'at');fprintf(fout,',*');fclose(fout);
        end
        % reset change indicator
        previous_change = current_change;
    end
    
    % change stimulus level
    SNR_dB = SNR_dB +  change*current_change;
    
    % if still on initial descent, change rules if SNR too low & change step size
    if (levitts_index==1 && SNR_dB<=InitialDescentMinimum)
        levitts_index=2;
        % change = change-inc;
    end
    
    % ensure that the current stimulus level is within the possible range
    % keep track of hitting the endpoints
    if (SNR_dB > MAX_SNR_dB)
        SNR_dB = MAX_SNR_dB;
        limit = limit+1;
    end
end  % end of a single run */

EndTime=fix(clock);
EndTimeString=sprintf('%02d:%02d:%02d',EndTime(4),EndTime(5),EndTime(6));
fout = fopen(SummaryOutFile, 'at');
%                  1      2        3        4                 5    6    7     8      9    10           11
fprintf(fout, 'listener,CondCode,TestType,MultipleMaskerType,warn, date,start,end,version,responses,feedback');
%                 12     13        14      15     16       17      18      19  20  21   22     23    24      25    26     27    28     29    30     31
fprintf(fout, ',targets,InQuiet,masker,masker2,CatchTrials,ear,FixedSound,rms,HRTF,T_az,M_az,Levitt,nTrials,finish,uRevs,sdRevs,nRevs,uLevs,sdLevs,nLevs\n');
fprintf(fout, '%s,%s,%s,%s,%d,%s,%s,%s,%4.1f,%s,', ...
    ListenerName,CondCode,TestType,MultipleMaskerType,WarningNoise,StartDate,StartTimeString,EndTimeString,VERSION,ResponseChoices);
if max(size(MultipleMaskerFiles))>1
    MaskerFile2=char(MultipleMaskerFiles(2));
else
    MaskerFile2='';
end
fprintf(fout, '%s,%s,%d,%s,%s,%d,%s,%s,%g,%s,%g,%g,%d,%d,', ...
    FeedBack,TargetsFile,PresentInQuiet,MaskerFile,MaskerFile2,CatchTrials,Ear,FixedSound,OutRMS,HRTF,TargetAz,MaskerAz,LevittsK,trial);

%% print out summary statistics -- how did we get here?
if (limit>=3) % bumped up against the limits
    fprintf(fout,'BUMPED,,,,,,');
else
    if strcmp(Cresp,'quit')  % test for quitting
        fprintf(fout, 'QUIT,');
    elseif (num_turns<FINAL_TURNS)
        fprintf(fout, 'RanOut,');
    else
        fprintf(fout, 'Normal,');
    end
    if num_turns>1
        fprintf(fout, '%5.2f,%5.2f,%d,', ...
            mean(reversals), std(reversals), num_turns);
    else
        fprintf(fout, '0,0,%d,',num_turns);
    end
    if num_final_trials>1
        fprintf(fout, '%5.2f,%5.2f,%d\n', ...
            mean(final_trials), std(final_trials), num_final_trials);
    else
        fprintf(fout, '0,0,%d\n',num_final_trials);
    end
end
fclose('all');

%% clean up
set(0,'ShowHiddenHandles','on');
delete(findobj('Type','figure'));
FinishButton; % indicate test is over
