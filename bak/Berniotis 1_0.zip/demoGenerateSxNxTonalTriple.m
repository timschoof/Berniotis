% function w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

ToneFreq=500;
InterauralTonePhase=0;
%InterauralTonePhase=pi;
NoiseBandLimits=[200 800];
fixed='noise';
%fixed='signal';
rms2use=0.05;
SNR=8;
SampFreq=44100;
Order=2;

w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq);

plot(w)
sound(w,SampFreq)