function w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

ISI=400;
ISIsamples=samplify(ISI,SampFreq);
ISIwave=zeros(ISIsamples,2);
%
% PreSilence=50;
% ISISamples=samplify(ISI,SampFreq);

% function [w, Nz, Tn]=GenerateSxNxTonalSound(TonePresent, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

w=[];
for i=1:3
    [x, ~, ~]=GenerateSxNxTonalSound((Order==i), ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq);
    w=vertcat(w,x);
    if i<3
      w=vertcat(w,ISIwave);
    end
end

