% function SpecifiedArgs=BerniotisParseArgs(ListenerName,varargin)

a=BerniotisParseArgs('L01','OutputDir', 'fuzzy')
