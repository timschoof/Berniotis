% function GenerateSxNxTonalSound(ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

ToneFreq=500;
InterauralTonePhase=0;
%InterauralTonePhase=pi;
NoiseBandLimits=[200 800];
fixed='noise';
%fixed='signal';
rms2use=0.1;
SNR=-120;
SampFreq=44100;

[w, Nz, Tn] = GenerateSxNxTonalSound(ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq);

pwelch(w,[],[],[],SampFreq)
figure
plot([Nz,Tn])

size(w)
plot(w)
sound(w,SampFreq)
%w(:,2)=0;



