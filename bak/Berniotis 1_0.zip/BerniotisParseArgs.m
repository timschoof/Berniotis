function SpecifiedArgs=BerniotisParseArgs(ListenerName,varargin)

% get arguments for Berniotis

% ToneFreq in Hz
% InteruralTonePhase = 0 or pi
% NoiseBandLimits = 2 element vector
% fixed =  'noise' or 'signal'
% rms2use
% SNR
% SampFreq  

p = inputParser;
p.addRequired('ListenerName', @ischar);
p.addParameter('ToneFreq', 500, @isnumeric);
p.addParameter('InterauralTonePhase', 0, @isnumeric);
p.addParameter('rms2use', 0.07, @isnumeric);
p.addParameter('NoiseBandWidth', 100, @isnumeric);   

p.addParameter('fixed', 'noise',  @(x)any(strcmpi(x,{'noise','signal'})));
p.addParameter('starting_SNR',20, @isnumeric);
p.addParameter('START_change_dB', 10, @isnumeric);
p.addParameter('LevittsK', 2, @isnumeric);
p.addParameter('INITIAL_TURNS', 3, @isnumeric);
p.addParameter('FINAL_TURNS', 6, @isnumeric); 
p.addParameter('InitialDescentMinimum', -22, @isnumeric);     
p.addParameter('FeedBack', 'Corrective', @ischar);
p.addParameter('MAX_TRIALS', 30, @isnumeric);
p.addParameter('FacePixDir', 'Bears', @ischar);
p.addParameter('MIN_change_dB', 2, @isnumeric);
p.addParameter('DEBUG', 0, @isnumeric);    
p.addParameter('MAX_SNR_dB', 22, @isnumeric);    
p.addParameter('IgnoreTrials', 3, @isnumeric); % number of initial trials to ignore errors on
p.addParameter('OutputDir','results', @ischar);
p.addParameter('StartMessage', 'none', @ischar);
p.addParameter('MaxBumps', 3, @isnumeric);   
p.addParameter('SampFreq', 44100, @isnumeric);    

% 
% p.addParameter('TargetsFile', 'Female1.txt', @ischar);
% p.addParamValue('MaskerFile', 'SpchNz.wav', @ischar);
% p.addParamValue('HRTF', 'none', @ischar);
% p.addParamValue('PresentInQuiet', 0, @(x)x==0 || x==1);
% p.addParamValue('CondCode', 'x', @ischar);
% p.addParamValue('Ear', 'B', @ischar);
% p.addParamValue('FixedSound', 'overall', @ischar);
% p.addParamValue('OutRMS', 0.05, @isnumeric); 
% p.addParamValue('WarningNoise', 0, @isnumeric);  

p.parse(ListenerName, varargin{:});
SpecifiedArgs=p.Results;

%     [ListenerName,TargetsFile,MaskerFile,starting_SNR,START_change_dB,MIN_change_dB,...
%         MAX_TRIALS,LevittsK,ResponseChoices,PresentInQuiet,HRTF,TargetAz,MaskerAz,CatchTrials, Ear]...
%         =SpecifyTestOrders;