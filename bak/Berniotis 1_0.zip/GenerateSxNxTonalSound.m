function [w, Nz, Tn]=GenerateSxNxTonalSound(TonePresent, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

% TonePresent = 0 or 1
% ToneFreq in Hz
% InteruralTonePhase = 0 or pi
% NoiseBandLimits = 2 element vector
% fixed =  'noise' or 'signal'
% rms2use
% SNR
% SampFreq

% all durations in ms
NoiseDuration=460;
ToneDuration=380;
RiseFall=40;

NzSamples=samplify(NoiseDuration,SampFreq);
ToneSamples=samplify(ToneDuration,SampFreq);
t=(0:(ToneSamples-1))/SampFreq;

Tone = zeros(1,max(ToneSamples,NzSamples));
Noise =  zeros(size(Tone));

% generate the noise and tone
f=[NoiseBandLimits(1)  NoiseBandLimits(1)+1  NoiseBandLimits(2)  NoiseBandLimits(2)+1];
l=[0   100   100   0];
[Nz, spect_length]=noise(f,l,SampFreq,NoiseDuration/1000);
Tn = sin(2*pi*ToneFreq*t);

% calculate the multiplicative factor for the signal-to-noise ratio
SNR = 10^(SNR/20);
if strcmp(fixed, 'noise') % fix the noise level and scale the signal
    Nz = rms2use * Nz/rms(Nz);
    Tn = Tn * (SNR*rms2use)/rms(Tn);
elseif strcmp(fixed, 'signal') % fix the signal level and scale the noise
    Nz = Nz * rms2use/(SNR * rms(Nz));
    Tn = Tn * rms2use/rms(Tn);
end

% Shorten the noise to the appropriate length
% put rises and falls on the sound pulses,
% and pad out Tone to appropriate length
% function s=taper(wave, rise, fall, SampFreq, type)
Nz = Nz(1:NzSamples);
Nz=taper(Nz, RiseFall, RiseFall, SampFreq)';
Tn=taper(Tn, RiseFall, RiseFall, SampFreq)';
if ToneSamples<NzSamples
    pre = round((NzSamples-ToneSamples)/2);
    post = (NzSamples-ToneSamples) - pre;
    Tn = vertcat(zeros(pre,1), Tn, zeros(post,1));
end
% plot(t,Tn)

if ~TonePresent
    Tn=Tn*0;
end
w1=Nz+Tn;
if InterauralTonePhase==pi
    w2=Nz-Tn;
elseif InterauralTonePhase==0
    w2=w1;
else
    error('InteruralTonePhase can only be 0 or pi')
end
w=horzcat(w1,w2);




