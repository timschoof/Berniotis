% function PlayAndReturnResponse3I3AFC(Wave2Play,trial,p)

clear
p=BerniotisParseArgs('L01');
FacesDir = fullfile('Faces',p.FacePixDir,'');
SmileyFace = imread(fullfile(FacesDir,'smile24.bmp'),'bmp');
WinkingFace = imread(fullfile(FacesDir,'wink24.bmp'),'bmp');
FrownyFace = imread(fullfile(FacesDir,'frown24.bmp'),'bmp');
%ClosedFace = imread(fullfile(FacesDir,'closed24.bmp'),'bmp');
%OpenFace = imread(fullfile(FacesDir,'open24.bmp'),'bmp');
%BlankFace = imread(fullfile(FacesDir,'blank24.bmp'),'bmp');
p.CorrectImage=SmileyFace;
p.IncorrectImage=FrownyFace;
p.Order=2;
% generate the appropriate sounds
w=GenerateSxNxTonalTriple(p);
%% ensure no overload
% function [OutWave, flag] = NoClipStereo(InWave,message)
[w, flag] = NoClipStereo(w);

trial=1;
[response1,p] = PlayAndReturnResponse3I3AFC(w,trial,p);

pause(2)

trial=2;
[response2,p]  = PlayAndReturnResponse3I3AFC(w,trial,p);

pause(1)
set(0,'ShowHiddenHandles','on');
delete(findobj('Type','figure'));

return


PlayAndReturnResponse3I3AFC(Wave2Play,trial,p)

