function samples=samplify(duration,SampFreq)
samples=round(SampFreq*duration/1000);