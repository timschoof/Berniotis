%% transposed stimuli - change 'InterauralTonePhase'from pi to 0 for NoSo
%% Here, test introduction of background noise
Berniotis('SR','fixed','signal','rms2use', 0.07,'NoiseBandWidth',100,...
    'InterauralTonePhase', pi, 'TranspositionFreq', 4000,'ToneFreq', 125, ...
    'VolumeSettingsFile', 'VolumeSettings4kHz.txt', ...
    'starting_SNR',80,...
    'BackNzPulsed', 0, 'BackNzLoPass', 1300, 'BackNzHiPass', 50, 'BackNzLevel', .005, ...
    'LongMaskerNoise', 0, ...
    'outputAllWavs', 1, 'DEBUG',1);
return

%% transposed stimuli - change 'InterauralTonePhase'from pi to 0 for NoSo
Berniotis('SR','fixed','noise','rms2use', 0.07,'NoiseBandWidth',100,...
    'InterauralTonePhase', pi, 'TranspositionFreq', 4000,'ToneFreq', 125, ...
    'DEBUG',0,'outputAllWavs', 1, 'VolumeSettingsFile', 'VolumeSettings4kHz.txt', ...
    'PlotTrackFile', 1)
return



Berniotis('TS','fixed','noise','rms2use', 0.07,'NoiseBandWidth',900,...
    'InterauralTonePhase', 0, 'NumSignalPulses', 3,'ToneDuration', 100,...
    'WithinPulseISI', 100,'NoiseDuration', 600,'TranspositionFreq', 4000, ...
    'outputAllWavs', 1)

%% Here's an example of a 3-pulse tonal target
Berniotis('SR','fixed','noise','rms2use', 0.07,'NoiseBandWidth',900,...
    'InterauralTonePhase', pi, 'NumSignalPulses', 3,'ToneDuration', 100,'WithinPulseISI', 100,'NoiseDuration', 600)
return

%% Here's an example of a 1-pulse tonal target with the 500 Hz condition of 2016 JASA paper
Berniotis('SR','fixed','noise','rms2use', 0.07,'NoiseBandWidth',900,...
    'InterauralTonePhase', pi)
return


Berniotis('SR','fixed','noise','rms2use', 0.07,'NoiseBandWidth',900,'NumSignalPulses', 3,'ToneDuration', 100,'WithinPulseISI', 100,'NoiseDuration', 600)
return

Berniotis('SR','fixed','noise','rms2use', 0.07,'NoiseBandWidth',900,'DEBUG',0,'outputAllWavs', 0)
return
Berniotis('SR','fixed','noise','rms2use', 0.03,'DEBUG',1,'outputAllWavs', 1)
return

Berniotis('SR','fixed','noise','rms2use', 0.07,'NumSignalPulses', 3,'ToneDuration', 100,'WithinPulseISI', 100,'NoiseDuration', 600)
return

Berniotis('SR','fixed','signal','rms2use', 0.03,'InterauralTonePhase', pi,'DEBUG',1)


return



Berniotis('SR','fixed','noise','rms2use', 0.03,'InterauralTonePhase', pi,'DEBUG',1)
