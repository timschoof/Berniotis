% function w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)
% 
% ToneFreq=500;
% InterauralTonePhase=0;
% %InterauralTonePhase=pi;
% NoiseBandLimits=[200 800];
% fixed='noise';
% %fixed='signal';
% rms2use=0.05;
% SNR=8;
% SampFreq=44100;

% p.Order=2;
p=BerniotisParseArgs('L27', 'starting_SNR',100,'rms2use', 0.15);

'TranspositionFreq', 4000,

w=GenerateSxNxTonalTriple(p);
% function [OutWave, flag] = no_clip(InWave,message)
[w, flag] = NoClipStereo(w);
return

plot(w)
sound(w,p.SampFreq)