dB=-20:20;
plot(dB, MyLogistic(dB,10,1))