function l = logistic(x)

y = exp(x);
l = y./(1+y);

