% function GenerateSxNxTonalSound(ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

clear
close all
p=BerniotisParseArgs('L01', 'NumSignalPulses', 3, 'starting_SNR',20,...
    'ToneDuration', 100, 'WithinPulseISI', 100, 'NoiseDuration', 600, 'fixed', 'signal');
p.trial = 1;

TonePresent=1;

[w, Nz, Tn] = GenerateSxNxTonalSound(TonePresent, p);

pwelch(w,[],[],[],p.SampFreq)
figure
plot([Nz,Tn])

size(w)
plot(w)
sound(w,p.SampFreq)
audiowrite('demoSxNx.wav',w,p.SampFreq)
%w(:,2)=0;



