% function SpecifiedArgs=BerniotisParseArgs(ListenerName,varargin)
clear
p=BerniotisParseArgs('L01','OutputDir', 'fuzzy')
p.trial = 1;

