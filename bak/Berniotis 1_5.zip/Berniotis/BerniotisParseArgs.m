function sArgs=BerniotisParseArgs(ListenerName,varargin)

% get arguments for Berniotis

% ToneFreq in Hz
% InteruralTonePhase = 0 or pi
% NoiseBandLimits = 2 element vector
% fixed =  'noise' or 'signal'
% rms2use
% SNR
% SampFreq  

p = inputParser;
p.addRequired('ListenerName', @ischar);
p.addParameter('TaskFormat', '3I-3AFC', @(x)any(strcmpi(x,{'3I-3AFC','3I-2AFC'})));
p.addParameter('ToneFreq', 500, @isnumeric);
p.addParameter('NumSignalPulses',  1, @isnumeric);
p.addParameter('ToneDuration', 400, @isnumeric);  
p.addParameter('WithinPulseISI', 100, @isnumeric);  
p.addParameter('NoiseDuration', 500, @isnumeric);
p.addParameter('LongMaskerNoise', 0, @isnumeric); 
% if 0, masker noise is pulsed along with target intervals
% if >0 = continuous through triple at given duration (ms)

p.addParameter('InterauralTonePhase', 0, @isnumeric);
p.addParameter('TranspositionFreq', 0, @isnumeric);
p.addParameter('TranspositionLoPassCutoff', 1500, @isnumeric);
p.addParameter('TranspositionSmoothingFilterOrder', 4, @isnumeric);  
p.addParameter('rms2use', 0.07, @isnumeric);
p.addParameter('NoiseBandWidth', 100, @isnumeric);   
p.addParameter('RiseFall', 50, @isnumeric);  
p.addParameter('ISI', 400, @isnumeric);  
p.addParameter('fixed', 'noise',  @(x)any(strcmpi(x,{'noise','signal'})));
p.addParameter('starting_SNR',20, @isnumeric);
p.addParameter('START_change_dB', 8, @isnumeric);
p.addParameter('MIN_change_dB', 2, @isnumeric);
p.addParameter('LevittsK', 2, @isnumeric);
p.addParameter('INITIAL_TURNS', 3, @isnumeric);
p.addParameter('FINAL_TURNS', 6, @isnumeric); 
p.addParameter('InitialDescentMinimum', -22, @isnumeric); 
p.addParameter('Order', 2, @isnumeric);
p.addParameter('FeedBack', 'Corrective', @ischar);
p.addParameter('MAX_TRIALS', 30, @isnumeric);
p.addParameter('FacePixDir', 'Bears', @ischar);
p.addParameter('PlotTrackFile', 0, @isnumeric);

p.addParameter('BackNzLevel',0, @isnumeric); % in absolute rms
p.addParameter('BackNzLoPass',0, @isnumeric);
p.addParameter('BackNzHiPass',50, @isnumeric);
p.addParameter('BackNzPulsed',0, @isnumeric); % 0 = continuous through triple


p.addParameter('DEBUG', 0, @isnumeric);    
p.addParameter('outputAllWavs', 0, @isnumeric); % for debugging purposes 
p.addParameter('MAX_SNR_dB', 22, @isnumeric);    
p.addParameter('IgnoreTrials', 3, @isnumeric); % number of initial trials to ignore errors on
p.addParameter('OutputDir','results', @ischar);
p.addParameter('StartMessage', 'none', @ischar);
p.addParameter('MaxBumps', 3, @isnumeric);   
p.addParameter('SampFreq', 44100, @isnumeric);    
p.addParameter('VolumeSettingsFile', 'VolumeSettings.txt', @ischar);

% p.addParamValue('PresentInQuiet', 0, @(x)x==0 || x==1);

p.parse(ListenerName, varargin{:});
sArgs=p.Results;
sArgs.SNR_dB = sArgs.starting_SNR; % current level
sArgs.NoiseBandLimits=[sArgs.ToneFreq-sArgs.NoiseBandWidth/2 sArgs.ToneFreq+sArgs.NoiseBandWidth/2];

if sArgs.TranspositionFreq>0
% lowpass filter for forwards/backwards
[sArgs.blo,sArgs.alo]=butter(sArgs.TranspositionSmoothingFilterOrder/2, ...
    ButterLoPassTweak(-1.5, sArgs.TranspositionLoPassCutoff, sArgs.TranspositionSmoothingFilterOrder/2)/(sArgs.SampFreq/2));
else
    sArgs.blo=0;,sArgs.alo=0;
end



%     [ListenerName,TargetsFile,MaskerFile,starting_SNR,START_change_dB,MIN_change_dB,...
%         MAX_TRIALS,LevittsK,ResponseChoices,PresentInQuiet,HRTF,TargetAz,MaskerAz,CatchTrials, Ear]...
%         =SpecifyTestOrders;