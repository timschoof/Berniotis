function [w, Nz, Tn]=GenerateSxNxTonalTriple(p)
% function w=GenerateSxNxTonalTriple(Order, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

ISIsamples=samplify(p.ISI,p.SampFreq);
ISIwave=zeros(ISIsamples,2);
%
% PreSilence=50;
% ISISamples=samplify(ISI,SampFreq);

% function [w, Nz, Tn]=GenerateSxNxTonalSound(TonePresent, ToneFreq, InterauralTonePhase, NoiseBandLimits, fixed, rms2use, SNR, SampFreq)

w=[];
Nz=[];
Tn=[];
for i=1:3
    [x, xNz, xTn]=GenerateSxNxTonalSound((p.Order==i), p);
    w=vertcat(w,x);
    Nz=vertcat(Nz,xNz);
    Tn=vertcat(Tn,xTn);
    if i<3
        w=vertcat(w,ISIwave);
        Nz=vertcat(Nz,ISIwave(:,1));
        Tn=vertcat(Tn,ISIwave(:,1));
    end
end

%% Transpose, if necessary
if p.TranspositionFreq>0
    % half-wave rectify
    w = (abs(w)+w)/2;
    % lowpass filter forwards/backwards 
    w=filtfilt(p.blo,p.alo,w);
    % create the modulator
    t=((0:(length(w)-1))/p.SampFreq)';
    sMod = sin(2*pi*p.TranspositionFreq*t);
    w = sMod.*w;
end

%% add in background noise
w = w + GenerateBackgroundNoise(p);


